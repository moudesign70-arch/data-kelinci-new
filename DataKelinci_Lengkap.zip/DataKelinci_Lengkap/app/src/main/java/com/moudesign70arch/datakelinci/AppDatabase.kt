package com.moudesign70arch.datakelinci

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class Rabbit(
    val id: Long = 0, val kode: String, val nama: String, val kelamin: String,
    val tanggalLahir: String, val ras: String, val warna: String, val bobot: String,
    val status: String, val catatan: String, val fotoUri: String? = null
)
data class Breeding(
    val id: Long = 0, val betinaId: Long, val jantanId: Long, val tanggal: String,
    val perkiraanLahir: String, val catatan: String
)

class AppDatabase(context: Context) : SQLiteOpenHelper(context, "data_kelinci.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE rabbits (
            id INTEGER PRIMARY KEY AUTOINCREMENT, kode TEXT NOT NULL UNIQUE,
            nama TEXT NOT NULL, kelamin TEXT NOT NULL, tanggal_lahir TEXT NOT NULL,
            ras TEXT NOT NULL, warna TEXT NOT NULL, bobot TEXT NOT NULL,
            status TEXT NOT NULL, catatan TEXT NOT NULL, foto_uri TEXT)""")
        db.execSQL("""CREATE TABLE breeding (
            id INTEGER PRIMARY KEY AUTOINCREMENT, betina_id INTEGER NOT NULL,
            jantan_id INTEGER NOT NULL, tanggal TEXT NOT NULL,
            perkiraan_lahir TEXT NOT NULL, catatan TEXT NOT NULL)""")
        seed(db)
    }
    private fun seed(db: SQLiteDatabase) {
        insertRabbit(db, Rabbit(kode="K001",nama="Mawar",kelamin="Betina",tanggalLahir="2025-01-10",ras="New Zealand",warna="Putih",bobot="3.2",status="Indukan",catatan="Sehat"))
        insertRabbit(db, Rabbit(kode="K002",nama="Bima",kelamin="Jantan",tanggalLahir="2025-02-05",ras="New Zealand",warna="Putih",bobot="3.5",status="Indukan",catatan="Sehat"))
        insertRabbit(db, Rabbit(kode="K003",nama="Luna",kelamin="Betina",tanggalLahir="2025-04-18",ras="Rex",warna="Cokelat",bobot="2.8",status="Anakan",catatan=""))
    }
    private fun values(r: Rabbit) = ContentValues().apply {
        put("kode",r.kode); put("nama",r.nama); put("kelamin",r.kelamin)
        put("tanggal_lahir",r.tanggalLahir); put("ras",r.ras); put("warna",r.warna)
        put("bobot",r.bobot); put("status",r.status); put("catatan",r.catatan); put("foto_uri",r.fotoUri)
    }
    private fun insertRabbit(db: SQLiteDatabase,r: Rabbit)=db.insert("rabbits",null,values(r))
    fun getRabbits(query:String="",sex:String="Semua"):List<Rabbit>{
        val q="%${query.trim()}%"
        val args=if(sex=="Semua") arrayOf(q,q,q) else arrayOf(q,q,q,sex)
        val where=if(sex=="Semua") "(kode LIKE ? OR nama LIKE ? OR ras LIKE ?)"
                   else "(kode LIKE ? OR nama LIKE ? OR ras LIKE ?) AND kelamin=?"
        val out=mutableListOf<Rabbit>()
        readableDatabase.query("rabbits",null,where,args,null,null,"nama ASC").use{c->
            while(c.moveToNext()) out.add(c.toRabbit())
        }; return out
    }
    fun saveRabbit(r:Rabbit):Long{
        return if(r.id==0L) writableDatabase.insertOrThrow("rabbits",null,values(r))
        else { writableDatabase.update("rabbits",values(r),"id=?",arrayOf(r.id.toString())); r.id }
    }
    fun deleteRabbit(id:Long){writableDatabase.delete("rabbits","id=?",arrayOf(id.toString()))}
    fun count(sex:String?=null):Int{
        val w=if(sex==null)"" else " WHERE kelamin=?"
        val a=if(sex==null)null else arrayOf(sex)
        readableDatabase.rawQuery("SELECT COUNT(*) FROM rabbits$w",a).use{c->return if(c.moveToFirst())c.getInt(0) else 0}
    }
    fun saveBreeding(b:Breeding)=writableDatabase.insert("breeding",null,ContentValues().apply{
        put("betina_id",b.betinaId);put("jantan_id",b.jantanId);put("tanggal",b.tanggal)
        put("perkiraan_lahir",b.perkiraanLahir);put("catatan",b.catatan)
    })
    fun getBreedings():List<Pair<Breeding,String>>{
        val out=mutableListOf<Pair<Breeding,String>>()
        readableDatabase.rawQuery("""SELECT b.*,f.nama betina,j.nama jantan FROM breeding b
            JOIN rabbits f ON f.id=b.betina_id JOIN rabbits j ON j.id=b.jantan_id
            ORDER BY b.tanggal DESC""",null).use{c->
            while(c.moveToNext()){
                val b=Breeding(c.getLong(c.getColumnIndexOrThrow("id")),
                    c.getLong(c.getColumnIndexOrThrow("betina_id")),
                    c.getLong(c.getColumnIndexOrThrow("jantan_id")),
                    c.getString(c.getColumnIndexOrThrow("tanggal")),
                    c.getString(c.getColumnIndexOrThrow("perkiraan_lahir")),
                    c.getString(c.getColumnIndexOrThrow("catatan")))
                out.add(b to "${c.getString(c.getColumnIndexOrThrow("betina"))} × ${c.getString(c.getColumnIndexOrThrow("jantan"))}")
            }
        };return out
    }
    private fun android.database.Cursor.toRabbit()=Rabbit(
        id=getLong(getColumnIndexOrThrow("id")),kode=getString(getColumnIndexOrThrow("kode")),
        nama=getString(getColumnIndexOrThrow("nama")),kelamin=getString(getColumnIndexOrThrow("kelamin")),
        tanggalLahir=getString(getColumnIndexOrThrow("tanggal_lahir")),ras=getString(getColumnIndexOrThrow("ras")),
        warna=getString(getColumnIndexOrThrow("warna")),bobot=getString(getColumnIndexOrThrow("bobot")),
        status=getString(getColumnIndexOrThrow("status")),catatan=getString(getColumnIndexOrThrow("catatan")),
        fotoUri=getString(getColumnIndexOrThrow("foto_uri")))
    override fun onUpgrade(db:SQLiteDatabase,oldVersion:Int,newVersion:Int){}
}
