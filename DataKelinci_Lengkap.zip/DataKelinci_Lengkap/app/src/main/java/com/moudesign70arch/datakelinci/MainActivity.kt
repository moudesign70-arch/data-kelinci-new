package com.moudesign70arch.datakelinci

import android.app.DatePickerDialog
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.*

class MainActivity:ComponentActivity(){
    override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContent{DataKelinciApp()}}
}

@Composable
fun DataKelinciApp(){
    val db=remember{AppDatabase(LocalContext.current.applicationContext)}
    var page by remember{mutableStateOf("Beranda")}
    var refresh by remember{mutableIntStateOf(0)}
    var selected by remember{mutableStateOf<Rabbit?>(null)}
    var edit by remember{mutableStateOf(false)}
    Scaffold(bottomBar={
        NavigationBar{listOf("Beranda","Kelinci","Perkawinan").forEach{p->
            NavigationBarItem(page==p,{page=p},{Text(if(p=="Beranda")"⌂" else if(p=="Kelinci")"🐇" else "♥")},{Text(p)})
        }}
    }){pad->Box(Modifier.padding(pad).fillMaxSize()){
        when(page){
            "Beranda"->Home(db,{page=it})
            "Kelinci"->RabbitList(db,{selected=null;edit=true},{selected=it;edit=true})
            else->BreedingPage(db,{refresh++})
        }
    }}
    if(edit)RabbitForm(db,selected,{edit=false},{edit=false;refresh++})
}

@Composable fun Home(db:AppDatabase,go:(String)->Unit){
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp)){
        Text("Data Kelinci",style=MaterialTheme.typography.headlineMedium)
        Text("Pencatatan peternakan • offline")
        Spacer(Modifier.height(18.dp))
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){
            Stat("Total",db.count().toString(),Modifier.weight(1f))
            Stat("Betina",db.count("Betina").toString(),Modifier.weight(1f))
            Stat("Jantan",db.count("Jantan").toString(),Modifier.weight(1f))
        }
        Spacer(Modifier.height(16.dp))
        Card(Modifier.fillMaxWidth()){Column(Modifier.padding(18.dp)){
            Text("Kelola Populasi & Siklus Biak",style=MaterialTheme.typography.titleLarge)
            Text("Data tersimpan di perangkat dan dapat digunakan tanpa internet.")
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
                Button({go("Kelinci")}){Text("Data Kelinci")}
                OutlinedButton({go("Perkawinan")}){Text("Perkawinan")}
            }
        }}
        Spacer(Modifier.height(12.dp))
        listOf("Tambah / edit / hapus data","Foto dengan Photo Picker","Pencarian & filter jenis kelamin","Catatan perkawinan","SQLite lokal/offline").forEach{ListItem(headlineContent={Text(it)})}
    }
}
@Composable fun Stat(t:String,v:String,m:Modifier){Card(m){Column(Modifier.padding(12.dp)){Text(v,style=MaterialTheme.typography.headlineSmall);Text(t)}}}

@Composable
fun RabbitList(db:AppDatabase,onAdd:()->Unit,onEdit:(Rabbit)->Unit){
    var q by remember{mutableStateOf("")};var sex by remember{mutableStateOf("Semua")}
    val data=db.getRabbits(q,sex)
    Column(Modifier.fillMaxSize().padding(16.dp)){
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){
            Text("Data Kelinci",style=MaterialTheme.typography.headlineSmall);Button(onAdd){Text("+ Tambah")}
        }
        OutlinedTextField(q,{q=it},Modifier.fillMaxWidth(),label={Text("Cari ID, nama, atau ras")})
        Row(horizontalArrangement=Arrangement.spacedBy(6.dp),modifier=Modifier.padding(vertical=7.dp)){
            listOf("Semua","Betina","Jantan").forEach{s->FilterChip(sex==s,{sex=s},label={Text(s)})}
        }
        LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)){items(data,key={it.id}){r->
            Card(Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp)){
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){
                    Column{Text(r.nama,style=MaterialTheme.typography.titleMedium);Text("${r.kode} • ${r.kelamin} • ${r.ras}")}
                    Text(r.status)
                }
                Text("Lahir: ${r.tanggalLahir} • Bobot: ${r.bobot} kg")
                if(r.catatan.isNotBlank())Text("Catatan: ${r.catatan}")
                TextButton({onEdit(r)}){Text("Edit")}
            }}
        }}
    }
}

@Composable
fun RabbitForm(db:AppDatabase,initial:Rabbit?,close:()->Unit,saved:()->Unit){
    val ctx=LocalContext.current
    var kode by remember{mutableStateOf(initial?.kode?:"")};var nama by remember{mutableStateOf(initial?.nama?:"")}
    var sex by remember{mutableStateOf(initial?.kelamin?:"Betina")};var lahir by remember{mutableStateOf(initial?.tanggalLahir?:"")}
    var ras by remember{mutableStateOf(initial?.ras?:"")};var warna by remember{mutableStateOf(initial?.warna?:"")}
    var bobot by remember{mutableStateOf(initial?.bobot?:"")};var status by remember{mutableStateOf(initial?.status?:"Anakan")}
    var cat by remember{mutableStateOf(initial?.catatan?:"")};var foto by remember{mutableStateOf(initial?.fotoUri)}
    var error by remember{mutableStateOf<String?>(null)}
    val picker=androidx.activity.compose.rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()){foto=it?.toString()}
    AlertDialog(onDismissRequest=close,title={Text(if(initial==null)"Tambah Kelinci" else "Edit Kelinci")},text={
        Column(Modifier.verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(6.dp)){
            OutlinedTextField(kode,{kode=it},label={Text("ID unik *")});OutlinedTextField(nama,{nama=it},label={Text("Nama *")})
            Row{FilterChip(sex=="Betina",{sex="Betina"},label={Text("Betina")});FilterChip(sex=="Jantan",{sex="Jantan"},label={Text("Jantan")})}
            OutlinedButton({val c=Calendar.getInstance();DatePickerDialog(ctx,{_,y,m,d->lahir="%04d-%02d-%02d".format(y,m+1,d)},c.get(1),c.get(2),c.get(5)).show()}){Text(if(lahir.isBlank())"Pilih tanggal lahir" else lahir)}
            OutlinedTextField(ras,{ras=it},label={Text("Ras *")});OutlinedTextField(warna,{warna=it},label={Text("Warna")})
            OutlinedTextField(bobot,{bobot=it},label={Text("Bobot (kg)")})
            Row(horizontalArrangement=Arrangement.spacedBy(3.dp)){listOf("Indukan","Anakan","Karantina","Dijual").forEach{s->FilterChip(status==s,{status=s},label={Text(s)})}}
            OutlinedButton({picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))}){Text(if(foto==null)"Pilih foto" else "Foto dipilih ✓")}
            OutlinedTextField(cat,{cat=it},label={Text("Catatan")},minLines=2)
            if(error!=null)Text(error!!,color=MaterialTheme.colorScheme.error)
        }
    },confirmButton={TextButton({
        error=when{kode.isBlank()||nama.isBlank()->"ID dan nama wajib diisi.";lahir.isBlank()->"Tanggal lahir wajib diisi.";ras.isBlank()->"Ras wajib diisi.";else->null}
        if(error==null)try{db.saveRabbit(Rabbit(initial?.id?:0,kode.trim(),nama.trim(),sex,lahir,ras.trim(),warna.trim(),bobot.trim(),status,cat.trim(),foto));saved()}catch(_:Exception){error="ID sudah digunakan atau data tidak valid."}
    }){Text("Simpan")}},dismissButton={Row{
        if(initial!=null)TextButton({db.deleteRabbit(initial.id);saved()}){Text("Hapus")}
        TextButton(close){Text("Batal")}
    }})
}

@Composable
fun BreedingPage(db:AppDatabase,reload:()->Unit){
    var show by remember{mutableStateOf(false)};val list=db.getBreedings()
    Column(Modifier.fillMaxSize().padding(16.dp)){
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("Perkawinan",style=MaterialTheme.typography.headlineSmall);Button({show=true}){Text("+ Catat")}}
        Spacer(Modifier.height(10.dp))
        if(list.isEmpty())Text("Belum ada catatan perkawinan.")
        LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)){items(list){(b,names)->Card(Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp)){
            Text(names,style=MaterialTheme.typography.titleMedium);Text("Tanggal kawin: ${b.tanggal}");Text("Perkiraan lahir: ${b.perkiraanLahir}");if(b.catatan.isNotBlank())Text("Catatan: ${b.catatan}")
        }}}}
    }
    if(show)BreedingDialog(db,{show=false;reload()})
}

@Composable
fun BreedingDialog(db:AppDatabase,close:()->Unit){
    val f=db.getRabbits("","Betina");val m=db.getRabbits("","Jantan");var ff by remember{mutableStateOf<Rabbit?>(null)}
    var mm by remember{mutableStateOf<Rabbit?>(null)};var date by remember{mutableStateOf("")};var note by remember{mutableStateOf("")};var error by remember{mutableStateOf<String?>(null)}
    val ctx=LocalContext.current
    AlertDialog(onDismissRequest=close,title={Text("Catat Perkawinan")},text={Column(Modifier.verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(5.dp)){
        Text("Induk betina");f.forEach{r->FilterChip(ff?.id==r.id,{ff=r},label={Text("${r.nama} (${r.kode})")})}
        Text("Pejantan");m.forEach{r->FilterChip(mm?.id==r.id,{mm=r},label={Text("${r.nama} (${r.kode})")})}
        OutlinedButton({val c=Calendar.getInstance();DatePickerDialog(ctx,{_,y,mo,d->date="%04d-%02d-%02d".format(y,mo+1,d)},c.get(1),c.get(2),c.get(5)).show()}){Text(if(date.isBlank())"Pilih tanggal kawin" else date)}
        OutlinedTextField(note,{note=it},label={Text("Catatan")});if(error!=null)Text(error!!,color=MaterialTheme.colorScheme.error)
    }},confirmButton={TextButton({
        if(ff==null||mm==null||date.isBlank())error="Pilih betina, jantan, dan tanggal." else try{
            val sdf=SimpleDateFormat("yyyy-MM-dd",Locale.US);val cal=Calendar.getInstance();cal.time=sdf.parse(date)!!;cal.add(Calendar.DAY_OF_YEAR,31)
            db.saveBreeding(Breeding(betinaId=ff!!.id,jantanId=mm!!.id,tanggal=date,perkiraanLahir=sdf.format(cal.time),catatan=note));close()
        }catch(_:Exception){error="Tanggal tidak valid."}
    }){Text("Simpan")}},dismissButton={TextButton(close){Text("Batal")}})
}
